import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Building, User, Settings, Bell, Lock, Palette, Globe, Shield, Zap, Mail, Phone, MapPin, Activity } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";

interface Organization {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  document: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zipCode: string | null;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function SettingsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [orgFormData, setOrgFormData] = useState({
    name: "",
    email: "",
    phone: "",
    document: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
  });

  const { data: organization, isLoading } = useQuery<Organization>({
    queryKey: ["/api/organizations/current"],
    queryFn: async () => {
      const res = await fetch("/api/organizations/current", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch organization");
      return res.json();
    },
  });

  useEffect(() => {
    if (organization) {
      setOrgFormData({
        name: organization.name,
        email: organization.email || "",
        phone: organization.phone || "",
        document: organization.document || "",
        address: organization.address || "",
        city: organization.city || "",
        state: organization.state || "",
        zipCode: organization.zipCode || "",
      });
    }
  }, [organization]);

  const updateOrganizationMutation = useMutation({
    mutationFn: async (data: typeof orgFormData) => {
      if (!organization) throw new Error("No organization");
      const res = await fetch(`/api/organizations/${organization.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update organization");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations/current"] });
      toast({ variant: "success", title: "Organização atualizada com sucesso!" });
    },
    onError: () => {
      toast({ variant: "destructive", title: "Erro ao atualizar organização" });
    },
  });

  const handleSubmitOrganization = (e: React.FormEvent) => {
    e.preventDefault();
    updateOrganizationMutation.mutate(orgFormData);
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center p-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Configurações
            </h1>
            <p className="text-muted-foreground mt-1">
              Gerencie as configurações da sua conta e organização
            </p>
          </div>
          <Badge variant="secondary" className="gap-2 px-4 py-2">
            <Settings className="h-4 w-4" />
            Sistema Ativo
          </Badge>
        </motion.div>

        <motion.div variants={itemVariants} className="grid gap-4 md:grid-cols-3">
          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Organização</p>
                  <p className="text-xl font-bold mt-2">{organization?.name || "—"}</p>
                </div>
                <div className="h-12 w-12 bg-blue-500/10 rounded-full flex items-center justify-center">
                  <Building className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <p className="text-xl font-bold mt-2 text-green-600">Verificado</p>
                </div>
                <div className="h-12 w-12 bg-green-500/10 rounded-full flex items-center justify-center">
                  <Shield className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Plano</p>
                  <p className="text-xl font-bold mt-2">Profissional</p>
                </div>
                <div className="h-12 w-12 bg-purple-500/10 rounded-full flex items-center justify-center">
                  <Zap className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Tabs defaultValue="organization" className="space-y-6">
            <TabsList className="grid w-full max-w-md grid-cols-3">
              <TabsTrigger value="organization" className="gap-2">
                <Building className="h-4 w-4" />
                Organização
              </TabsTrigger>
              <TabsTrigger value="account" className="gap-2">
                <User className="h-4 w-4" />
                Conta
              </TabsTrigger>
              <TabsTrigger value="preferences" className="gap-2">
                <Palette className="h-4 w-4" />
                Preferências
              </TabsTrigger>
            </TabsList>

          <TabsContent value="organization">
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                    <Building className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <CardTitle>Informações da Organização</CardTitle>
                    <CardDescription>
                      Atualize as informações da sua empresa
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitOrganization} className="space-y-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="org-name" className="text-base font-semibold flex items-center gap-2">
                        <Building className="h-4 w-4" />
                        Nome da Organização *
                      </Label>
                      <Input
                        id="org-name"
                        value={orgFormData.name}
                        onChange={(e) => setOrgFormData({ ...orgFormData, name: e.target.value })}
                        required
                        className="text-base"
                        placeholder="Digite o nome da organização"
                      />
                    </div>

                    <Separator />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="org-email" className="flex items-center gap-2">
                          <Mail className="h-4 w-4" />
                          Email
                        </Label>
                        <Input
                          id="org-email"
                          type="email"
                          value={orgFormData.email}
                          onChange={(e) => setOrgFormData({ ...orgFormData, email: e.target.value })}
                          placeholder="email@empresa.com"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="org-phone" className="flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          Telefone
                        </Label>
                        <Input
                          id="org-phone"
                          value={orgFormData.phone}
                          onChange={(e) => setOrgFormData({ ...orgFormData, phone: e.target.value })}
                          placeholder="(11) 98765-4321"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="org-document" className="flex items-center gap-2">
                        <Shield className="h-4 w-4" />
                        CNPJ
                      </Label>
                      <Input
                        id="org-document"
                        value={orgFormData.document}
                        onChange={(e) => setOrgFormData({ ...orgFormData, document: e.target.value })}
                        placeholder="00.000.000/0000-00"
                      />
                    </div>

                    <Separator />

                    <div className="space-y-4">
                      <Label className="text-base font-semibold flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        Endereço
                      </Label>

                      <div className="space-y-2">
                        <Input
                          id="org-address"
                          value={orgFormData.address}
                          onChange={(e) => setOrgFormData({ ...orgFormData, address: e.target.value })}
                          placeholder="Rua, Avenida, número"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="org-city">Cidade</Label>
                          <Input
                            id="org-city"
                            value={orgFormData.city}
                            onChange={(e) => setOrgFormData({ ...orgFormData, city: e.target.value })}
                            placeholder="São Paulo"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="org-state">Estado</Label>
                          <Input
                            id="org-state"
                            value={orgFormData.state}
                            onChange={(e) => setOrgFormData({ ...orgFormData, state: e.target.value })}
                            maxLength={2}
                            placeholder="SP"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="org-zipCode">CEP</Label>
                          <Input
                            id="org-zipCode"
                            value={orgFormData.zipCode}
                            onChange={(e) => setOrgFormData({ ...orgFormData, zipCode: e.target.value })}
                            placeholder="00000-000"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-4">
                    <Button type="button" variant="outline">
                      Cancelar
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={updateOrganizationMutation.isPending}
                      className="gap-2 shadow-lg shadow-primary/20"
                    >
                      {updateOrganizationMutation.isPending && (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      )}
                      Salvar Alterações
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="account">
            <div className="space-y-6">
              <Card className="border-border/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <User className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle>Segurança da Conta</CardTitle>
                      <CardDescription>
                        Gerencie suas credenciais e autenticação
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Lock className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Senha</p>
                        <p className="text-sm text-muted-foreground">Última alteração há 30 dias</p>
                      </div>
                    </div>
                    <Button variant="outline">Alterar Senha</Button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Shield className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Autenticação de Dois Fatores</p>
                        <p className="text-sm text-muted-foreground">Adicione uma camada extra de segurança</p>
                      </div>
                    </div>
                    <Badge variant="outline">Em Breve</Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Activity className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Sessões Ativas</p>
                        <p className="text-sm text-muted-foreground">Gerencie seus dispositivos conectados</p>
                      </div>
                    </div>
                    <Button variant="outline">Ver Sessões</Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                      <Bell className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle>Notificações</CardTitle>
                      <CardDescription>
                        Configure como você deseja ser notificado
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Email</p>
                        <p className="text-sm text-muted-foreground">Receber notificações por email</p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Activity className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Atividades</p>
                        <p className="text-sm text-muted-foreground">Alertas sobre ações importantes</p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="preferences">
            <div className="space-y-6">
              <Card className="border-border/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 bg-gradient-to-br from-pink-500 to-pink-600 rounded-lg flex items-center justify-center">
                      <Palette className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle>Aparência</CardTitle>
                      <CardDescription>
                        Personalize a interface do sistema
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div>
                      <p className="font-medium">Tema</p>
                      <p className="text-sm text-muted-foreground">Escolha entre claro, escuro ou automático</p>
                    </div>
                    <Badge variant="secondary">Sistema</Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div>
                      <p className="font-medium">Cor de Destaque</p>
                      <p className="text-sm text-muted-foreground">Cor principal da interface</p>
                    </div>
                    <div className="h-8 w-8 bg-primary rounded-full border-2 border-background shadow-lg"></div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center">
                      <Globe className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle>Regionalização</CardTitle>
                      <CardDescription>
                        Idioma, moeda e formato de data
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Idioma</Label>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <p className="font-medium">Português (Brasil)</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Moeda</Label>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <p className="font-medium">R$ - Real Brasileiro</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Formato de Data</Label>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <p className="font-medium">DD/MM/AAAA</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}

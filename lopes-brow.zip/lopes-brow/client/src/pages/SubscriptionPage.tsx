import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, Zap, Star, CreditCard, Calendar, TrendingUp, Download, Loader2, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

interface Subscription {
  id: string;
  status: string;
  plan: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
}

export default function SubscriptionPage() {
  const [csrfToken, setCsrfToken] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch((error) => console.error("Failed to fetch CSRF token:", error));
  }, []);

  const { data: subscription, isLoading: isLoadingSubscription } = useQuery<Subscription>({
    queryKey: ["/api/subscription"],
    queryFn: async () => {
      const res = await fetch("/api/subscription", { credentials: "include" });
      if (!res.ok) {
        if (res.status === 404) return null;
        throw new Error("Failed to fetch subscription");
      }
      return res.json();
    },
  });

  const createCheckoutMutation = useMutation({
    mutationFn: async (priceId: string) => {
      const res = await fetch("/api/stripe/create-checkout-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify({ priceId }),
      });
      if (!res.ok) throw new Error("Failed to create checkout session");
      return res.json();
    },
    onSuccess: (data: { url?: string }) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao criar checkout",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createPortalMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/stripe/create-portal-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify({ returnUrl: window.location.href }),
      });
      if (!res.ok) throw new Error("Failed to create portal session");
      return res.json();
    },
    onSuccess: (data: { url?: string }) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao abrir portal",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const plans = [
    {
      name: "Personal",
      price: 29.90,
      priceId: process.env.STRIPE_PRICE_PERSONAL_MONTHLY || "price_personal_monthly",
      features: [
        "Até 1.000 transações/mês",
        "2 usuários",
        "10 GB armazenamento",
        "Relatórios básicos",
        "Suporte por email",
      ],
      icon: Zap,
      color: "blue",
    },
    {
      name: "Business",
      price: 99.90,
      priceId: process.env.STRIPE_PRICE_BUSINESS_MONTHLY || "price_business_monthly",
      features: [
        "Até 5.000 transações/mês",
        "10 usuários",
        "50 GB armazenamento",
        "Relatórios avançados",
        "Suporte prioritário",
        "Exportação ilimitada",
      ],
      icon: Crown,
      color: "purple",
      popular: true,
    },
    {
      name: "Enterprise",
      price: 299.90,
      priceId: process.env.STRIPE_PRICE_ENTERPRISE_MONTHLY || "price_enterprise_monthly",
      features: [
        "Transações ilimitadas",
        "Usuários ilimitados",
        "200 GB armazenamento",
        "Todos os relatórios",
        "Suporte 24/7",
        "API personalizada",
        "Gerente de conta dedicado",
      ],
      icon: Star,
      color: "orange",
    },
  ];

  if (isLoadingSubscription) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="ml-2 text-muted-foreground">Carregando assinatura...</p>
        </div>
      </AppLayout>
    );
  }

  const currentPlan = subscription?.plan || "Free";
  const isActive = subscription?.status === "active";

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants}>
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Minha Assinatura
            </h1>
            <p className="text-muted-foreground mt-1">
              Gerencie sua assinatura e histórico de pagamentos
            </p>
          </div>
        </motion.div>

        {!subscription && (
          <motion.div variants={itemVariants}>
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Você está no plano gratuito. Faça upgrade para desbloquear recursos avançados!
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        {subscription && (
          <motion.div variants={itemVariants}>
            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                  <div className="flex items-center gap-4">
                    <div className="h-16 w-16 bg-white/20 rounded-full flex items-center justify-center">
                      <Crown className="h-8 w-8" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold">Plano {currentPlan}</h2>
                      <p className="opacity-90 mt-1">
                        {subscription.cancelAtPeriodEnd ? "Cancela em" : "Renova em"}{" "}
                        {new Date(subscription.currentPeriodEnd).toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                      variant="secondary"
                      className="gap-2"
                      onClick={() => createPortalMutation.mutate()}
                      disabled={createPortalMutation.isPending}
                    >
                      {createPortalMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <CreditCard className="h-4 w-4" />
                      )}
                      Gerenciar Assinatura
                    </Button>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-white/20 grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm opacity-75">Status</p>
                    <Badge className={`mt-1 ${isActive ? "bg-green-500 hover:bg-green-600" : "bg-yellow-500 hover:bg-yellow-600"}`}>
                      {subscription.status === "active" ? "Ativo" : subscription.status}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm opacity-75">
                      {subscription.cancelAtPeriodEnd ? "Cancela em" : "Próxima cobrança"}
                    </p>
                    <p className="font-semibold mt-1">
                      {new Date(subscription.currentPeriodEnd).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  {subscription.cancelAtPeriodEnd && (
                    <div>
                      <p className="text-sm opacity-75">Cancelamento</p>
                      <p className="font-semibold mt-1">Agendado</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Comparar Planos</CardTitle>
              <CardDescription>Veja todos os planos disponíveis e faça upgrade</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                {plans.map((plan) => {
                  const Icon = plan.icon;
                  const isCurrentPlan = plan.name === currentPlan;
                  return (
                    <Card key={plan.name} className={`relative ${isCurrentPlan ? "border-primary ring-2 ring-primary/20" : ""}`}>
                      {plan.popular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
                          <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white border-0 shadow-lg flex items-center gap-1 px-3 py-1">
                            <Star className="h-3 w-3 fill-current" />
                            Mais Popular
                          </Badge>
                        </div>
                      )}
                      <CardContent className="pt-6">
                        <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                          <Icon className="h-6 w-6 text-primary" />
                        </div>
                        <h3 className="text-2xl font-bold">{plan.name}</h3>
                        <div className="mt-2 mb-6">
                          <span className="text-4xl font-bold">
                            R$ {plan.price.toFixed(2)}
                          </span>
                          <span className="text-muted-foreground">/mês</span>
                        </div>
                        <ul className="space-y-3 mb-6">
                          {plan.features.map((feature, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                              <span className="text-sm">{feature}</span>
                            </li>
                          ))}
                        </ul>
                        <Button
                          className="w-full"
                          variant={isCurrentPlan ? "outline" : "default"}
                          disabled={isCurrentPlan || createCheckoutMutation.isPending}
                          onClick={() => createCheckoutMutation.mutate(plan.priceId)}
                        >
                          {createCheckoutMutation.isPending ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Carregando...
                            </>
                          ) : isCurrentPlan ? (
                            "Plano Atual"
                          ) : (
                            "Selecionar Plano"
                          )}
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {subscription && (
          <motion.div variants={itemVariants}>
            <Card>
              <CardHeader>
                <CardTitle>Informações Importantes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
                  <AlertCircle className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="font-medium">Stripe não configurado</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Para ativar pagamentos completos, configure suas credenciais do Stripe nas variáveis de ambiente.
                      Consulte a documentação para mais detalhes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </motion.div>
    </AppLayout>
  );
}

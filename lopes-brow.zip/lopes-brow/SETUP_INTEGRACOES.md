# Guia de Configuração de Integrações - LUCREI

Este documento lista todas as integrações necessárias para o funcionamento completo do sistema LUCREI.

## ✅ Configurações Já Prontas

### Banco de Dados PostgreSQL
- **Status**: ✅ Configurado e funcionando
- **Variável**: `DATABASE_URL`
- **Detalhes**: Banco de dados PostgreSQL via Neon está configurado e as tabelas foram criadas

### Sessão e Segurança
- **Status**: ✅ Configurado
- **Variável**: `SESSION_SECRET`
- **Detalhes**: Chave secreta para gerenciamento de sessões está configurada

---

## ⚠️ Integrações Pendentes (Necessário Configurar)

### 1. Stripe (Pagamentos e Assinaturas)

**Status**: ⚠️ Não configurado - Sistema funcionará mas sem processamento de pagamentos

**Variáveis Necessárias**:
```bash
STRIPE_SECRET_KEY=sk_live_... ou sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_live_... ou pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

**Como Obter**:
1. Acesse https://stripe.com e crie uma conta
2. Vá em Developers > API Keys
3. Copie as chaves Secret e Publishable
4. Configure o webhook endpoint: `https://seu-dominio.com/api/webhooks/stripe`
5. Copie o Webhook Secret

**Impacto**: 
- Sem Stripe: Sistema não processará pagamentos
- Página de assinaturas não funcionará completamente
- Checkout de planos não estará disponível

---

### 2. Sentry (Monitoramento de Erros)

**Status**: ⚠️ Não configurado - Sistema funcionará mas sem tracking de erros

**Variável Necessária**:
```bash
SENTRY_DSN=https://...@sentry.io/...
```

**Como Obter**:
1. Acesse https://sentry.io e crie uma conta
2. Crie um novo projeto para Node.js/React
3. Copie o DSN fornecido

**Impacto**:
- Sem Sentry: Erros não serão rastreados automaticamente
- Debugging em produção será mais difícil
- Não terá alertas automáticos de erros críticos

---

### 3. Resend (Envio de Emails)

**Status**: ⚠️ Não configurado - Sistema funcionará mas sem envio de emails

**Variável Necessária**:
```bash
RESEND_API_KEY=re_...
```

**Como Obter**:
1. Acesse https://resend.com e crie uma conta
2. Vá em API Keys
3. Gere uma nova API key

**Impacto**:
- Sem Resend: Emails transacionais não serão enviados
- Notificações de faturas por email não funcionarão
- Recuperação de senha não funcionará
- Verificação de email não funcionará

---

## 🔧 Como Adicionar as Variáveis de Ambiente

### No Replit:
1. Clique em "Secrets" (ícone de chave) no painel lateral
2. Adicione cada variável de ambiente
3. Reinicie o servidor

### Localmente (desenvolvimento):
1. Crie um arquivo `.env` na raiz do projeto:
```bash
# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Sentry
SENTRY_DSN=https://...@sentry.io/...

# Resend
RESEND_API_KEY=re_...
```

2. Nunca faça commit do arquivo `.env` (já está no .gitignore)

---

## 📊 Prioridade de Configuração

### Alta Prioridade (Necessário para produção):
1. ✅ **Stripe** - Para processar pagamentos e assinaturas
2. ✅ **Resend** - Para enviar emails transacionais importantes

### Média Prioridade (Recomendado):
3. ✅ **Sentry** - Para monitorar erros e performance

---

## 🧪 Teste de Integração

Após configurar cada integração, teste:

### Stripe:
```bash
# Teste via dashboard ou CLI do Stripe
stripe listen --forward-to localhost:5000/api/webhooks/stripe
```

### Sentry:
- Verifique se erros estão aparecendo no dashboard do Sentry
- Force um erro de teste para validar

### Resend:
- Teste enviando um email de boas-vindas
- Verifique se chegou na caixa de entrada

---

## 📝 Notas Importantes

1. **Ambiente de Teste vs Produção**:
   - Use chaves de teste (`test_...`) durante desenvolvimento
   - Use chaves de produção (`live_...`) apenas em produção

2. **Segurança**:
   - Nunca compartilhe suas chaves secretas
   - Nunca faça commit de chaves no código
   - Rotacione as chaves periodicamente

3. **Custos**:
   - Stripe: Taxa por transação (geralmente 2.9% + R$ 0,39)
   - Sentry: Plano gratuito disponível (5k eventos/mês)
   - Resend: Plano gratuito disponível (3k emails/mês)

---

## ✅ Status Atual do Sistema

**Funcionalidades Operacionais SEM as integrações**:
- ✅ Landing page
- ✅ Cadastro e login de usuários
- ✅ Dashboard
- ✅ Gestão de clientes
- ✅ Gestão de faturas
- ✅ Transações financeiras
- ✅ Relatórios e gráficos
- ✅ Categorias e centros de custo
- ✅ Contas bancárias
- ✅ Documentos
- ✅ Tags
- ✅ Importação OFX
- ✅ Exportação de dados (Excel, CSV, JSON, PDF)
- ✅ Reconciliação bancária

**Funcionalidades que REQUEREM integrações**:
- ⚠️ Processamento de pagamentos (requer Stripe)
- ⚠️ Envio de emails transacionais (requer Resend)
- ⚠️ Monitoramento de erros em produção (requer Sentry)

---

## 🚀 Próximos Passos

1. Configure as integrações listadas acima
2. Teste cada integração individualmente
3. Faça deploy para produção
4. Configure monitoramento e alertas
5. Configure backups automáticos do banco de dados

Para dúvidas ou suporte, consulte a documentação oficial de cada serviço.
